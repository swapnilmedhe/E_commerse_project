package com.cybage.boot.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="myorder")
public class Order {
	@Id
	@NotNull
	Integer orderid;
	Integer total;
	Integer amount;
	
	@JsonIgnore
	@OneToOne(mappedBy="order")
	 private Payment payment;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CUSTOMER_ID_FK")
	Customer customer;
	
	@JsonIgnore
	@OneToMany
	@JoinColumn(name="ORDER_ID_FK")
	private List<Product> product = new ArrayList<Product>();

//	@ManyToMany
//	@JoinColumn(name="Customer_ID_FK")
//	Customer customer;
  // many to one mapping ..........
	
	
	
	
	
	
	
}
