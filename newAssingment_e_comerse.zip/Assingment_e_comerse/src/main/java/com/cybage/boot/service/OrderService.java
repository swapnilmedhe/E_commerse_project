package com.cybage.boot.service;

import java.util.List;

import com.cybage.boot.model.Order;


public interface OrderService {
	
	
	
	public boolean saveOrder(Order order);
	
	public boolean deleteorderbyorderid(Integer orderid);
	
	
	
	
/*	public boolean addWeight(UserWeight weight,int uId);
	
	public List<UserWeight> getUserWeight(int uId);
	
	public boolean deleteWeight(int wId);
	

	

	public boolean updateWeight(UserWeight weight);
	
	public List<?> getUserWeightList();*/
	
}
