package com.cybage.boot.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.cybage.boot.model.Customer;





@Repository
@Transactional
public interface CustomerRepo extends JpaRepository<Customer, Integer> {
	
	Customer findByEmail(String email);
	
//	@Modifying
//	@Transactional
//	@Query(value= "select *  from customer" ,nativeQuery=true)
	
	//Customer findByEmailAndPassword(String email ,String password);
	
	Customer findByEmailAndPassword(String email ,String password);

	 public List<Customer>findAll();
	
}
