package com.cybage.boot.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.cybage.boot.model.Customer;
import com.cybage.boot.model.Product;


public interface ProductService {
	
	
	public boolean saveProduct(Product product);
	
	List<Product> findByproductid(Integer id);
	
	
	public boolean deleteproductByproductid(Integer productid);
	
	List<Product> findproduct();
	
	
	
	
}
