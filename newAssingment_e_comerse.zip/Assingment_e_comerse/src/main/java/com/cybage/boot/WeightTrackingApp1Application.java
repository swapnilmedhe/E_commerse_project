package com.cybage.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeightTrackingApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(WeightTrackingApp1Application.class, args);
	}

}
