package com.cybage.boot.service;

import java.util.List;

import com.cybage.boot.model.Order;
import com.cybage.boot.model.Payment;


public interface Paymentservice {
	
	
	
	public boolean savepayment(Payment payment);
	
	public boolean deletepaymentbypaymentid(Integer paymentid);
	
/*	public boolean addWeight(UserWeight weight,int uId);
	
	public List<UserWeight> getUserWeight(int uId);
	
	public boolean deleteWeight(int wId);
	
	public boolean updateWeight(UserWeight weight);
	
	public List<?> getUserWeightList();*/
	
	
}
