package com.cybage.boot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cybage.boot.model.Product;

import com.cybage.boot.repository.ProductRepo;

@Service
public class productServiceImp implements ProductService{
	 	 
	 @Autowired
	 private ProductRepo productrepo;

	@Override
	public boolean saveProduct(Product product) {
		productrepo.save(product);
		return true;
	}

	@Override
	public List<Product> findByproductid(Integer productid) {
		// TODO Auto-generated method stub
		List l=productrepo.findByproductid(productid);
		return l;
	}
	
	public List<Product> deleteproduct(Integer productid)
	{
		
		return productrepo.findAll();
	}

	
	@Override
	public boolean deleteproductByproductid(Integer productid) {
		// TODO Auto-generated method stub
		
		productrepo.deleteproductByproductid(productid);
		
		return true;
	}

	
	@Override
	public List<Product> findproduct() {
		// TODO Auto-generated method stub
		return productrepo.findAll();
	}

//	@Override
//	public boolean findproduct() {
//		productrepo.findAll();
//		return true;
//	}

	
	







	
	
}
