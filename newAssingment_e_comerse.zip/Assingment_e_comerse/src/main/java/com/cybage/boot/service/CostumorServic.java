package com.cybage.boot.service;

import java.util.List;

import com.cybage.boot.model.Customer;

public interface CostumorServic {
	
	public Customer findUserByEmailAndPassword(String email, String password);
	
	public boolean saveCustomer(Customer customer);	
	
	public List<Customer> findAll();
	
	
}
