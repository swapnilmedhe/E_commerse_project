package com.cybage.boot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="payment")
public class Payment {


	@Id
	@NotNull
	Integer paymentid;
	
	@Column(name = "grand_total")
	Integer grand_total;
	
	
	@OneToOne
	@JoinColumn(name="ORDERID_FK")
	@JsonIgnore
	private Order order;
	
	@OneToOne
	@JoinColumn(name="CUSTOMER_FK")
	@JsonIgnore
	private Customer cusmomer;

	public Integer getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(Integer paymentid) {
		this.paymentid = paymentid;
	}

	public Integer getGrand_total() {
		return grand_total;
	}

	public void setGrand_total(Integer grand_total) {
		this.grand_total = grand_total;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Customer getCusmomer() {
		return cusmomer;
	}

	public void setCusmomer(Customer cusmomer) {
		this.cusmomer = cusmomer;
	}
	
	
	
}
