package com.cybage.boot.controller;

import java.io.Console;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.boot.model.Customer;
import com.cybage.boot.model.Order;
import com.cybage.boot.model.Payment;
import com.cybage.boot.model.Product;
import com.cybage.boot.service.CostumorServic;
import com.cybage.boot.service.OrderService;
import com.cybage.boot.service.Paymentservice;
import com.cybage.boot.service.ProductService;
import com.cybage.boot.service.orderServiceImp;

import net.minidev.json.JSONArray;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Controller {

	//logger
	private static final Logger logger = LoggerFactory.getLogger(Controller.class);
	
	@Autowired
	private CostumorServic customerservice; 
	
	@Autowired
	private ProductService productservice; 
	
	@Autowired
	private  OrderService orderservice;
	
	@Autowired
	private  Paymentservice paymentservice;
	

//login user.
	@PostMapping(path= "/login" , consumes = "application/json", produces = "application/json" )
	public ResponseEntity<Customer> login(@RequestBody Customer u) {
	  System.out.println("inside user controller"+u.getEmail()+u.getPassword());
	  System.out.println("****Checking****"+customerservice.findUserByEmailAndPassword(u.getEmail(), u.getPassword())+"<----------->");
	if(customerservice.findUserByEmailAndPassword(u.getEmail(), u.getPassword()) != null )
	{
	  logger.info("Returning User Object for Login");
      System.out.println("Welcome..");
      Customer c =customerservice.findUserByEmailAndPassword(u.getEmail(), u.getPassword());
       int user =c.getCid();
      return new ResponseEntity<Customer>(HttpStatus.ACCEPTED);
	}
	   return new ResponseEntity<Customer>(HttpStatus.FORBIDDEN);
	} 

	
	
	
	//register user 
	 @PostMapping("/register")
	 public ResponseEntity<HttpStatus> register(@RequestBody Customer customer) {
		 System.out.println("inside register "+customer);
		if(customerservice.saveCustomer(customer)) {
			logger.info("Returning status Ok for User Registration");
			System.out.println("Customer register successfully!");
			return ResponseEntity.ok(HttpStatus.OK);
		}
		else
			System.out.println("Customer registration fail!!!!");

			return ResponseEntity.ok(HttpStatus.UNAUTHORIZED);
	 }
	 
//this.history.pushState(null, 'login');


	 //adding the product 
	 @PostMapping("/register/addproduct")
	 public ResponseEntity<HttpStatus> addproduct(@RequestBody Product product) {
		
		if(productservice.saveProduct(product)) {
			logger.info("Returning status Ok for add product");
			return ResponseEntity.ok(HttpStatus.OK);
		}
		else
			return ResponseEntity.ok(HttpStatus.UNAUTHORIZED);
	 }
	 
	 
	 
	 	 //delete product by product id
	 @DeleteMapping(value="/deleteproduct/{productid}")
		public ResponseEntity<HttpStatus> deleteproduct(@PathVariable("productid") Integer productid){
			if(productservice.deleteproductByproductid(productid)) {
				System.out.println("Inside delete controller---->"+productid);
				logger.info("Data to be Delete with productid"+productid);
				return ResponseEntity.ok(HttpStatus.OK);
			}
			return ResponseEntity.ok(HttpStatus.FORBIDDEN);
		}
	 
	 
	 
	 //get products
	 @GetMapping("/getproducts")
	 public List<Product> getproducts() {
		
		if(productservice.findproduct().size()>1){
			logger.info("Returning status Ok for list Customers");
		 List l=productservice.findproduct();
		for(Product c:productservice.findproduct())
		{
			System.out.println(c.getPname()+c.getPdesc()+c.getPprice());
		}
		
			
		return l;
		}
		else
			return null;
	 }
	 
	

 // get customers 
	 @GetMapping("/getcustomer")
	 public ResponseEntity<HttpStatus> getCustomer() {
		
		if(customerservice.findAll().size()>0){
			logger.info("Returning status Ok for list Customers");
		customerservice.findAll();
		for(Customer c:customerservice.findAll())
		{
			//System.out.println(c.getfName()+c.get);
		}
		
			
		return ResponseEntity.ok(HttpStatus.OK);
		}
		else
			return ResponseEntity.ok(HttpStatus.UNAUTHORIZED);
	 }


	 //adding the order 
	 @PostMapping("/addorder")
	 public ResponseEntity<HttpStatus> addorder(@RequestBody Order order) {
		
		if(orderservice.saveOrder(order)) {
			logger.info("Returning status Ok for add order");
			return ResponseEntity.ok(HttpStatus.OK);
		}
		else
			return ResponseEntity.ok(HttpStatus.UNAUTHORIZED);
	 }
	 
	 
	
	 
	 
	 //delete order
	 @DeleteMapping(value="/deleteorder/{orderid}")
		public ResponseEntity<HttpStatus> deleteorder(@PathVariable("orderid") Integer orderid){
			if(orderservice.deleteorderbyorderid(orderid)) {
				logger.info("Data to be Delete with productid"+orderid);
				return ResponseEntity.ok(HttpStatus.OK);
			}
			return ResponseEntity.ok(HttpStatus.FORBIDDEN);
		}
	 
	
	 
	 // adding payment
		 @PostMapping("/addpayment")
		 public ResponseEntity<HttpStatus> addpayment(@RequestBody Payment payment) {
			
			if(paymentservice.savepayment(payment)) {
				logger.info("Returning status Ok for add payment");
				return ResponseEntity.ok(HttpStatus.OK);
			}
			else
				return ResponseEntity.ok(HttpStatus.UNAUTHORIZED);
		 }
		 
		 //delete payment
		 @DeleteMapping(value="/deletpayment/{paymentid}")
			public ResponseEntity<HttpStatus> deletpayment(@PathVariable("paymentid") Integer paymentid){
				if(paymentservice.deletepaymentbypaymentid(paymentid)) {
					logger.info("Data to be Delete with paymentid"+paymentid);
					return ResponseEntity.ok(HttpStatus.OK);
				}
				return ResponseEntity.ok(HttpStatus.FORBIDDEN);
			}
		 
	
}
