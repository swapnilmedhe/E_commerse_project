package com.cybage.boot.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cybage.boot.model.Customer;
import com.cybage.boot.model.Product;


@Repository
public interface ProductRepo extends JpaRepository<Product, Integer> {

	List<Product> findByproductid(Integer productid);
	
	
	@Modifying
	@Transactional
	@Query(value= "delete from product where productid =?1" ,nativeQuery=true)
	public void deleteproductByproductid(Integer productid);
	
	public List<Product> findAll();
	
}
