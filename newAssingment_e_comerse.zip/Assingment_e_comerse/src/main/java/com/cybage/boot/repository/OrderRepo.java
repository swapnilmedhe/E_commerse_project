package com.cybage.boot.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cybage.boot.model.Customer;
import com.cybage.boot.model.Order;
import com.cybage.boot.model.Product;


@Repository
public interface OrderRepo extends JpaRepository<Order, Integer> {
	
	List <Order> findByOrderid(Integer orderid);
	
	@Modifying
	@Transactional
	@Query(value= "delete from myorder where orderid =?1" ,nativeQuery=true)
	public void deleteorderbyorderid(Integer orderid);
	
	
}
