package com.cybage.boot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cybage.boot.model.Customer;
import com.cybage.boot.repository.CustomerRepo;

@Service
public class CustomerServiceImp implements CostumorServic {
	
	@Autowired
	CustomerRepo  customerrepo;

	
	//validate 
	@Override
	public Customer findUserByEmailAndPassword(String email, String password) {
		/*return customerrepo.findByEmailAndPassword(email, password);*/
		return customerrepo.findByEmailAndPassword(email, password);
	}

	
	@Override
	public boolean saveCustomer(Customer customer) {
		customerrepo.save(customer);
		return true;
	}



	@Override
	public List<Customer> findAll() {
	
		return customerrepo.findAll();
	}
	
	
	
	
	
//	@Override
//	public List<Customer> getUserUserList(Customer customer) {
//		// TODO Auto-generated method stub
//		return customer.getEmail() ;
//	}


}
