package com.cybage.boot.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer cid;
	
	@Column(name = "email", unique=true)
	String email;
	
	@Column(name = "fName")
	String fName;
	
	@Column(name = "lName")
	String lName;
	
	@Column(name = "password")
	String password;
	
	@Column(name = "address")
	String address;
	
	
	//mapping one to one 
	@OneToOne(cascade = {CascadeType.ALL})
	@JoinColumn(name="ROLL_ID_FK")
	 private Roll roll;
	
	// mapping one to many
	@OneToMany(mappedBy="customer")
	private List<Order> orders = new ArrayList<Order>();
	
	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}




	@OneToOne(mappedBy="cusmomer")
	private Payment payment;

	public Integer getCid() {
		return cid;
	}

   public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Roll getRoll() {
		return roll;
	}

	public void setRoll(Roll roll) {
		this.roll = roll;
	}
	
	
	// parameter less constructor 
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	//parameterize constructor 
	public Customer(@NotNull Integer cid, String email, String fName, String lName, String password, String address,
			Roll roll, List<Order> orders, Payment payment) {
		super();
		this.cid = cid;
		this.email = email;
		this.fName = fName;
		this.lName = lName;
		this.password = password;
		this.address = address;
		this.roll = roll;
		this.orders = orders;
		this.payment = payment;
	}

	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", email=" + email + ", fName=" + fName + ", lName=" + lName + ", password="
				+ password + ", address=" + address + ", roll=" + roll + "]";
	}
	
	

	
}
