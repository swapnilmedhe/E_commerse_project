package com.cybage.boot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cybage.boot.model.Order;
import com.cybage.boot.model.Payment;

import com.cybage.boot.repository.OrderRepo;
import com.cybage.boot.repository.PaymentRepo;

@Service
public class PaymentServiceImp implements Paymentservice{
	 
	 @Autowired
	 private PaymentRepo paymentRepo;

	@Override
	public boolean savepayment(Payment payment) {
		paymentRepo.save(payment);
		return true;
	}

	
	@Override
	public boolean deletepaymentbypaymentid(Integer paymentid) {
		paymentRepo.deletepaymentbypaymentid(paymentid);
		return true;
	}

	 
	/*@Override
	public boolean saveOrder(Order order) {
		
		orderrepo.save(order);
		return true;
	}

	
	@Override
	public boolean deleteorderbyorderid(Integer orderid) {
		 
		orderrepo.deleteorderbyorderid(orderid);
		return true;
	}*/
	 
	 

	 
	
}
