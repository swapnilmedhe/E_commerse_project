/*package com.cybage.boot;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import com.cybage.boot.controller.UserController;
import com.cybage.boot.model.User;
import com.cybage.boot.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;


public class UserControllerTest extends WeightTrackingApp1ApplicationTests {
	
	
private MockMvc mockMvc;
	
	
	@Autowired
	UserService userServiceMock;
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	
	@Test
	public void findAllWeightTest() throws Exception {
		mockMvc.perform(get("/getweight/1")).andExpect(status().isOk())
		.andExpect(content().contentType("application/json;charset=UTF-8"))
		.andExpect(jsonPath("$.[0].wId").value(4)).andExpect(jsonPath("$.[0].weight").value("56"))
		.andExpect(jsonPath("$.[0].time").value("2019-03-07T10:40:11.000+0000"))
		.andExpect(jsonPath("$.[1].wId").value(7)).andExpect(jsonPath("$.[1].weight").value("59.6"))
		.andExpect(jsonPath("$.[1].time").value("2019-03-07T10:42:25.000+0000"))
		.andExpect(jsonPath("$.[2].wId").value(14)).andExpect(jsonPath("$.[2].weight").value("60.7"))
		.andExpect(jsonPath("$.[2].time").value("2019-03-07T11:11:35.000+0000"));
		

}


	@Test
	public void loginTest() throws Exception {
	String jsonString="{\"email\": \"aditya@gmail.com\", \"password\": \"aditya@123\" } ";
	ResultActions resultActions  = mockMvc.perform(post("/login")
            .contentType(MediaType.APPLICATION_JSON)
            .content(jsonString));
	resultActions.andExpect(status().isOk());

	
	}
	
	@Test
	public void addWeightTest() throws Exception {
	String jsonString="{\"weight\": \"60.7\"} ";
	ResultActions resultActions  = mockMvc.perform(post("/addweight/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(jsonString));
	resultActions.andExpect(status().isOk());
	
	
	}
	
	@Test
	public void updateWeightTest() throws Exception {
	String jsonString = "{\"wId\": \"7\", \"weight\": \"59.6\", \"time\": \"2019-03-07\",\"user\":{\"fname\": \"Aditya\", \"lname\": \"Sawant\",\"email\": \"aditya@gmail.com\",\"password\": \"aditya@123\"} } ";

			
	ResultActions resultActions  = mockMvc.perform(put("/updateweight")
            .contentType(MediaType.APPLICATION_JSON)
            .content(jsonString));
	resultActions.andExpect(status().isOk());
	
	
	}
	
	@Test
	public void deleteWeightTest() throws Exception {
	//String jsonString = "{\"wId\": \"18\", \"weight\": \"10\", \"time\": \"2019-03-06\",\"user\":{\"fname\": \"Aditya\", \"lname\": \"Sawant\",\"email\": \"adi@gmail.com\",\"password\": \"adi@123\"} } ";

			
	ResultActions resultActions  = mockMvc.perform(delete("/deleteweight/5")
            .contentType(MediaType.APPLICATION_JSON)
            .content(""));
	resultActions.andExpect(status().isOk());
	
	
	}
}
	

	@Test
	public void loginTest() throws Exception {
		  ResultMatcher ok = MockMvcResultMatchers.status()
                  .isOk();
		//String jsonString="{\"email\": \"apu@gmail.com\", \"password\": \"Apu@123\" } ";
		mockMvc.perform(post("/login")).param("email","apu@gmail.com").andExpect(status().isOk())
		.andExpect(content().contentType("application/json;charset=UTF-8"))
		.andExpect(jsonPath("$.fName").value("Apurva")).andExpect(jsonPath("$.lName").value("Hedaoo"))
		.andExpect(jsonPath("$.email").value("apu@gmail.com")).andExpect(jsonPath("$.password").value("Apu@123"))
		.andExpect(jsonPath("$.uId").value(2));
		
}
	
	
	



	public static String asJsonString(final Object obj) {
	    try {
	        return new ObjectMapper().writeValueAsString(obj);
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }

	}
	
	
	
	
	@Test
	public void loginTest() throws Exception { 
	    String url =  "/object";
	    User user = new User();
	    user.setEmail("apu@gmail.com");
	    user.setPassword("Apu@123");
	    //... more
	    
	    ObjectMapper mapper = new ObjectMapper();
	    mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
	    ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
	    String requestJson=ow.writeValueAsString(user );

	    mockMvc.perform(post(url).contentType("application/json;charset=UTF-8")
	        .content(requestJson))
	        .andExpect(status().isOk())
	        .andExpect(jsonPath("$.fName").value("Apurva")).andExpect(jsonPath("$.lName").value("Hedaoo"))
			.andExpect(jsonPath("$.email").value("apu@gmail.com")).andExpect(jsonPath("$.password").value("Apu@123"))
			.andExpect(jsonPath("$.uId").value(2));
			
	}


    @Test
    public void findAllWeightTest() throws Exception {
        findAll first = new findAllBuilder()
                .wId(7)
                .weight("58")
                .time("2019-03-05T06:48:59.000+0000")
                .build();
        findAll second = new findAllBuilder()
        		  .wId(8)
                  .weight("56")
                  .time("2019-03-05T06:49:02.000+0000")
                  .build();
        findAll third = new findAllBuilder()
      		  .wId(9)
                .weight("57")
                .time("2019-03-05T06:49:06.000+0000")
                .build();
        when(userServiceMock.findAll()).thenReturn(Arrays.asList(first, second,third));
        
        mockMvc.perform(get("/getweight/{uId}"))
        .andExpect(status().isOk())
        .andExpect(content().contentType(TestUtil.APPLICATION_JSON_UTF8))
        .andExpect(jsonPath("$", hasSize(3)))
        .andExpect(jsonPath("$[0].wId", is(7)))
        .andExpect(jsonPath("$[0].weight", is("58")))
        .andExpect(jsonPath("$[0].time", is("2019-03-05T06:48:59.000+0000")))
        .andExpect(jsonPath("$[1].wId", is(8)))
        .andExpect(jsonPath("$[1].weight", is("56")))
        .andExpect(jsonPath("$[1].time", is("2019-03-05T06:49:02.000+0000")))
        ..andExpect(jsonPath("$[1].wId", is(9)))
        .andExpect(jsonPath("$[1].weight", is("57")))
        .andExpect(jsonPath("$[1].time", is("2019-03-05T06:49:06.000+0000")))

verify(userServiceMock, times(1)).findAll(1);
verifyNoMoreInteractions(userServiceMock);
}
 
	

@Override
@Before
public void setUp(){
	super.setUp();	
}
@Test
public void findAllWeight() throws Exception{
	String uri="/getweight/{uId}";
	MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).
			accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
	int status = mvcResult.getResponse().getStatus();
	assertEquals(200,status);
	String content = mvcResult.getResponse().getContentAsString();
	User[] weightlist = super.mapFromJson(content, User[].class);
	assertTrue(weightlist.length>0);
	
}
*/