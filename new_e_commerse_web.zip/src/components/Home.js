import React, { Component } from 'react';
import HomeDisplay  from './HomeDisplay'
import '../App.css';



class Home extends Component {
  

  render() {
   
    return (
      <div className="homedisplay">
            <HomeDisplay/>
      </div>
    )
  }
}


export default Home
