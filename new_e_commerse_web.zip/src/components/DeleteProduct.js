import React, { Component } from 'react';
import { Navbar, Nav, Form, Button, FormControl ,Col} from "react-bootstrap";
import axios from "axios";

class DeleteProduct extends Component {

    constructor(props) {
        super(props);
    
        this.state = {
          productid:0,
        };
      }
    
      handleSubmit = (e) =>
        {
           e.preventDefault();
           console.log("inside handle submit");
           console.log(this.state);
    
          this.deleteProduct(this.state.productid);
        }
          
        deleteProduct = (id) =>
        {  console.log(id);
           axios.delete(`http://localhost:8080/deleteproduct/${id}`).then( res =>console.log( res.productid+" product deleted ..")).catch(err => console.log("error"));
        }
  render() {
    let style={
        left: 300,
        width:500,height:250,top:50
  
       }
    return (
        <div className="ui card " style={style}>
        <div className="ui ">
        <h4 className="ui purple header"> Delete product by id ... </h4>
         <hr></hr>
         
        </div>
       <Form onSubmit={this.handleSubmit}>
       <Form.Group controlId="formBasicEmail">
           <Form.Label>Product Id</Form.Label>
           <Form.Control
             type="number"
             placeholder="Enter product id to delete product ..."
             onChange={e => {
               this.setState({ productid: e.target.value });
             }}
           />
           <Form.Text className="text-muted" />
         </Form.Group>
         <Button variant="danger" type="submit">
         Delete product
         </Button>
       </Form>
     </div>
    )
  }
}

export default DeleteProduct;
