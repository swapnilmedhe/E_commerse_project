import React, { Component } from 'react';
import { Navbar, Nav, Form, Button, FormControl ,Col} from "react-bootstrap";
import axios from "axios";
import  { Redirect } from 'react-router-dom';


class AddProduct extends Component {
    constructor(props) {
        super(props);
    
        this.state = {
          productid:0,
           pname:"",
           pdesc:"",
           pprize:0,
           isDelete:false

        };
      }
    
      handleSubmit = (e) =>
        {
           e.preventDefault();
           console.log("inside handle submit");
           console.log(this.state);
    
          this.loginChecker(this.state);
        }
          
        loginChecker = (state) =>
        {
            axios.post('http://localhost:8080/register/addproduct',state).then( res =>console.log( res.status+" Register Successfully.."),
            window.location.reload()
             
            ).catch(err => console.log("error"));
        }


        handledelete =(e) =>
        {
          e.preventDefault();
          this.setState({ isDelete: true });
        }
    
  render() {
    let style={
      left: 300,
      width:400,height:250,top:50

     }
     if (this.state.isDelete) {
      return <Redirect to='/deleteproduct' />
     // return <Redirect to = {{ pathname: "/addproduct" }} />;
    }
    return (
        <div className="ui card " style={style}>
        <div className="ui ">
        <h4 className="ui purple header"> Add product... </h4>
         <hr></hr>
         
        </div>
       <Form onSubmit={this.handleSubmit}>
       <Form.Group controlId="formBasicEmail">
           <Form.Label>Product Id</Form.Label>
           <Form.Control
             type="number"
             placeholder="eg . 4xx"
             onChange={e => {
               this.setState({ productid: e.target.value });
             }}
           />
           <Form.Text className="text-muted" />
         </Form.Group>

         <Form.Group controlId="formBasicEmail">
           <Form.Label>Product Name</Form.Label>
          
           <Form.Control
             type="text"
             placeholder="product Name"
             onChange={e => {
               this.setState({ pname: e.target.value });
             }}
           />
           <Form.Text className="text-muted" />
         </Form.Group>

         <Form.Group controlId="formBasicEmail">
           <Form.Label>Product Desc</Form.Label>
           <Form.Control
             type="text"
             placeholder="product desc ...."
             onChange={e => {
               this.setState({ pdesc: e.target.value });
             }}
           />
           <Form.Text className="text-muted" />
         </Form.Group>

         <Form.Group controlId="formBasicEmail">
           <Form.Label>Product prize</Form.Label>
           <Form.Control
             type="Number"
             placeholder="Enter Amount ...."
             onChange={e => {
               this.setState({ pprice: e.target.value });
             }}
           />
           <Form.Text className="text-muted" />
         </Form.Group>

        
         <Button variant="primary" type="submit">
          Add product
         </Button>
          <hr></hr>
         <Button variant="danger" onClick={ (e) =>{this.handledelete(e)}}>
          Delete product
         </Button>
       </Form>
     </div>
    )
  }
}



export default AddProduct;
