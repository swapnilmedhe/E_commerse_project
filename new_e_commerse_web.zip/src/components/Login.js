  import React, { Component } from 'react';
  import { Navbar, Nav, Form, Button, FormControl } from "react-bootstrap";
  import axios from 'axios';
  import  { Redirect } from 'react-router-dom';
  import {browserHistory} from 'react-dom';


  
  class Login extends Component {
    
    constructor(props)
    {
        super(props);

        this.state={
          email:"",
          password: "",
          isSignedUp: false
        }
      //  this.renderRedirectToRegister = this.renderRedirectToRegister.bind(this);
    }

    handleSubmit = (e) =>
    {
       e.preventDefault();
       console.log("inside handle submit");
       console.log(this.state);

      this.loginChecker(this.state);
    }

    // renderRedirect = () => {
    
    //     return <Redirect to='/addproduct' />
    //   }
    loginChecker = (state) =>
    {  
        //axios.post('http://localhost:8080/login',state).then( console.log("Welcome ..")).catch( error => console.log(error +"try again"));
        axios({
          method: 'post',
          url: 'http://localhost:8080/login',
          data: state
      })
      .then((response) => {

          console.log(response.status+"Welcome.....");
          if (response.status === 202) {
            this.setState({ isSignedUp: true }); // after signing up, set the state to true. This will trigger a re-render
          }
  
      })
      .catch(function (error) {
          console.log(error+"Try agian.........");
          alert("Try again..............")
          return <Redirect to='/' />
      });
      
    }
  //   renderRedirectToRegister = () => {
 
  //    // return <Redirect to={{pathname: '/register'}} />
  //    return <Redirect to='/register' />
  // }




    render() {
       let style={
        left: 300,
        width:400,height:250,top:50

       }
       if (this.state.isSignedUp) {
        return <Redirect to='/addproduct' />
       // return <Redirect to = {{ pathname: "/addproduct" }} />;
      }
      return (
        <div className="ui card " style={style}>
          <h3>Login Here</h3>
          <Form onSubmit={this.handleSubmit}>
            <Form.Group controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control type="email" placeholder="abc@xyz.com" onChange={(e) =>{this.setState({email:e.target.value})}} />
              <Form.Text className="text-muted">
              </Form.Text>
            </Form.Group>
        
            <Form.Group controlId="formBasicPassword">
               <Form.Label>Password</Form.Label>
               <Form.Control type="password" placeholder="Password"onChange={(e) =>{this.setState({password:e.target.value})}} />

            </Form.Group>
           
            <Button variant="primary" type="submit">
               Log In
            </Button>
            
          </Form>
        </div>
      )
    }
  }
  
  export default Login
  
  