import React, { Component } from 'react';
import '../App.css';
import axios from 'axios';

class AllProducts extends Component {
    constructor()
    {
        super();
        this.state={
            products:[]
        }

    }


  componentDidMount()
  {
    this.getProduct();
  }

    getProduct = () => {
        axios.get(`http://localhost:8080/getproducts`)
             .then((res) => this.setState({ products: res.data }))
            .catch((error) => console.log("error"));
    }
   

  render() {
    console.log(this.state.products);
    let{products} =this.state;
    const productlist=products.map((x) => 
    <div className="card pname">
          <div className="content">
            <div className="header">{x.productid} </div>
            <div className="meta "> {x.pdesc}</div>
            <div className="description">
            
             {x.pname}
            </div>
          </div>
        </div>
    
    
    )
   

    return (
        <div className="ui cards pname">
        {productlist}
        </div>
    )
  }
}

export default AllProducts;
