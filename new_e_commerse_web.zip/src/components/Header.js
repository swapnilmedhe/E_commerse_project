import React from  'react';
import {Navbar,Nav,Form,Button,FormControl} from 'react-bootstrap';
import {Link,BrowserRouter,Route} from 'react-router-dom';
import Home from './Home';
import Login from './Login';
import AllProducts from './AllProducts';
import '../App.css';



function Header() {
 
  return (
   
    <Navbar bg="primary" variant="dark">
    <Navbar.Brand href="#home">E_Comerse_web
    
    </Navbar.Brand>
   
    <Nav className="mr-auto" variant="dark">
     
      <BrowserRouter> 
      <Link to ="/" className="link" onClick={() => window.location.refresh()} > Home </Link> &nbsp;&nbsp;&nbsp;&nbsp;
      <Link to ="/register" className="link" onClick={() => window.location.refresh()} > Register</Link> &nbsp;&nbsp;&nbsp;&nbsp;
      <Link to ="/login" className="link" onClick={() => window.location.refresh()}> Login</Link> &nbsp;&nbsp;&nbsp;&nbsp;
      <Link to ="/addproduct" className="link" onClick={() => window.location.refresh()}> </Link> &nbsp;&nbsp;&nbsp;&nbsp;
      <Link to ="/getproducts" className="link" onClick={() => window.location.refresh()}> </Link> &nbsp;&nbsp;&nbsp;&nbsp;
      {/* <Route path="/" exact component ={Home}/>
      <Route path="/login" component ={Login}/>  */}
      </BrowserRouter>

    </Nav>

  </Navbar>
 

  )
}

export default Header;
