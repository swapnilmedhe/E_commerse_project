import React, { Component } from "react";
import { Navbar, Nav, Form, Button, FormControl, Col } from "react-bootstrap";
import axios from "axios";

class Register extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      fName: "",
      lName: "",
      password: "",
      address: "",
      roll:{rollid:0}       
      
    };
  }

  handleSubmit = e => {
    e.preventDefault();
    console.log("inside handle submit");
    console.log(this.state);

    this.loginChecker(this.state);
  };

  loginChecker = state => {
    // axios
    //   .post("http://localhost:8080/register", state)
    //   .then(res => console.log(res + " Register Successfully.."))
    //   .catch(err => console.log("error"));

    axios({
      method: 'post',
      url: 'http://localhost:8080/register',
      data: state
  })
  .then(function (response) {
      console.log(response);
  })
  .catch(function (error) {
      console.log(error);
  });
  };

 
  render() {
    let style = {
      left: 300,
      width: 450,
      top: 50
    };

    return (
      <div className="ui card " style={style}>
        <div className="ui ">
          <h4 class="ui purple header">Register </h4>
          <hr />
        </div>
        <Form onSubmit={this.handleSubmit}>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              placeholder="abc@xyz.com"
              onChange={e => {
                this.setState({ email: e.target.value });
              }}
            />
            <Form.Text className="text-muted" />
          </Form.Group>

          <Form.Group controlId="formBasicEmail">
            <Form.Label>First Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="enter your name"
              onChange={e => {
                this.setState({ fName: e.target.value });
              }}
            />                                

            <Form.Text className="text-muted" />
          </Form.Group>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Last Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="enter last name"
              onChange={e => {
                this.setState({ lName: e.target.value });
              }}
            />

            <Form.Text className="text-muted" />
          </Form.Group>
          <Form.Group controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              onChange={e => {
                this.setState({ password: e.target.value });
              }}
            />
          </Form.Group>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Address</Form.Label>
            <Form.Control
              type="text"
              placeholder="enter address"
              onChange={e => {
                this.setState({ address: e.target.value });
              }}
            />


            <Form.Text className="text-muted" />
          </Form.Group>

          <Form.Group as={Col} controlId="formGridState">
            <Form.Label>Select Role : 0 Admine 1: Customer</Form.Label>
            <Form.Control
              as="select"
              onChange={e => {
                this.setState({ roll: { ...this.state.roll,  rollid: e.target.value} });
               // this.setState({ rollid: e.target.value });
              }}
            >
              <option value="0">Customer</option>
              <option value="1">Admine</option>
            </Form.Control>
          </Form.Group>

      
          <Button variant="primary" type="submit">
            Register
          </Button>
        </Form>
      </div>
    );
  }
}

export default Register;
