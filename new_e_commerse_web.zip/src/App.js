import React from 'react';
import Header from './components/Header';
import {Route,BrowserRouter,Switch} from 'react-router-dom';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import AddProduct from './components/AddProduct';
import DeleteProduct from './components/DeleteProduct';
import AllProducts from './components/AllProducts';
import './App.css';

function App() {
  return (
    <div className="App">
      <Header/>
      <BrowserRouter>
      <Switch>
      <Route path="/" exact component ={Home}/>
      <Route path="/login" component ={Login}/> 
      <Route path="/register" component ={Register}/> 
      <Route path="/addproduct" component ={AddProduct}/> 
      <Route path="/deleteproduct" component ={DeleteProduct}/> 
      <Route path="/getproducts" component ={AllProducts}/> 
      
      </Switch>
     
      </BrowserRouter>
    </div>
  );
}

export default App;
